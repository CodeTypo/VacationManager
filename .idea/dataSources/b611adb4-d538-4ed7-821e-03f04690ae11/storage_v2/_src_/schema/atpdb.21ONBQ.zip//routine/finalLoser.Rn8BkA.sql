create
    definer = root@localhost procedure finalLoser(OUT playerName varchar(100), OUT tournament_id varchar(3))
begin
 declare min int default 1;
 declare max int;
 declare random int;
 select count(*) into max from tournaments;
 select FLOOR( RAND() * (max-min) + min) into random;
 select pl.player_name, t.tournament_id into playerName, tournament_id
 from matches m
 join tournaments t on t.tournament_id = m.tournament_id
 join players pl on m.loser_player_id = pl.player_id
 where m.round_name = 'Finals'
 and t.tournament_id = concat('T', random) ;
end;

