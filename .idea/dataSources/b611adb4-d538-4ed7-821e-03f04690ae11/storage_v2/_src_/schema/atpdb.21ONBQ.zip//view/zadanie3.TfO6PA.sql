create view zadanie3 as
select `t`.`tournament_name` AS `tournament_name`,
       `t`.`tournament_type` AS `tournament_type`,
       `m`.`round_name`      AS `round_name`,
       `pw`.`player_name`    AS `winner`,
       `pl`.`player_name`    AS `loser`,
       `m`.`winner_seed`     AS `winner_seed`,
       `m`.`loser_seed`      AS `loser_seed`,
       `m`.`set1_score`      AS `set1_score`,
       `m`.`set2_score`      AS `set2_score`,
       `m`.`set3_score`      AS `set3_score`,
       `m`.`set4_score`      AS `set4_score`,
       `m`.`set5_score`      AS `set5_score`
from (((`atpdb`.`matches` `m` join `atpdb`.`players` `pw` on ((`m`.`winner_player_id` = `pw`.`player_id`))) join `atpdb`.`players` `pl` on ((`m`.`loser_player_id` = `pl`.`player_id`)))
         join `atpdb`.`tournaments` `t` on ((`m`.`tournament_id` = `t`.`tournament_id`)))
where ((`pw`.`player_name` = 'Roger Federer') or (`pl`.`player_name` = 'Roger Federer'));

