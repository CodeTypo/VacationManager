create
    definer = root@localhost procedure getPurse(IN playerName varchar(100), OUT purse int)
begin
 declare tournamentName varchar(100) default 'australian-open';
 declare wins int default 0; 
 select count(*) into wins
 from matches m
 join tournaments t on t.tournament_id = m.tournament_id
 join players pw on pw.player_id = m.winner_player_id
 where t.tournament_name = tournamentName
 and pw.player_name = playerName;
 if wins = 7 then SET purse = 3700;
 elseif wins = 6 then set purse = 1900;
 elseif wins = 5 then set purse = 900; 
 elseif wins = 4 then set purse = 440;
 elseif wins = 3 then set purse = 220;
 elseif wins = 2 then set purse = 130;
 elseif wins = 1 then set purse = 80;
 else set purse = 50;
 end if;
end;

