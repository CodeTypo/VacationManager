create
    definer = root@localhost function getResult(firstPlayer varchar(20), secondPlayer varchar(20)) returns varchar(30) deterministic
begin

declare result varchar (30);
declare matchesWin varchar (30);
declare matchesLose varchar(30);

select count(*) into matchesLose from matches m
join players pw on m.winner_player_id = pw.player_id
join players pl on m.loser_player_id = pl.player_id
where pw.player_name = secondPlayer and pl.player_name = firstPlayer;

select count(*) into matchesWin from matches m
join players pw on m.winner_player_id = pw.player_id
join players pl on m.loser_player_id = pl.player_id
where pw.player_name = firstPlayer and pl.player_name = secondPlayer;

return concat(matchesWin, ":", matchesLose);

end;

