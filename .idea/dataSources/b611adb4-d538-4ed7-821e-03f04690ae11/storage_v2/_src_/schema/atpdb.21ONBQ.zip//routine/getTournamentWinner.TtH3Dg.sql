create
    definer = root@localhost function getTournamentWinner(tournamentName varchar(30)) returns varchar(30) deterministic
begin

declare tournamentWinner varchar(30);

select pw.player_name into tournamentWinner from matches m
join players pw on m.winner_player_id = pw.player_id
join tournaments t on m.tournament_id = t.tournament_id
where t.tournament_name = tournamentName and m.round_name = 'Finals';

return tournamentWinner;

end;

